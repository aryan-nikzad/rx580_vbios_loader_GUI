[Defines]
  DSC_SPECIFICATION              = 1.28
  PLATFORM_NAME                  = Rx580ReBarDxe
  PLATFORM_GUID                  = 1a45f7c8-0b22-4f55-97af-4dba1d63eb71
  PLATFORM_VERSION               = 0.1
  OUTPUT_DIRECTORY               = Build/Rx580ReBarDxe
  SUPPORTED_ARCHITECTURES        = X64
  BUILD_TARGETS                  = DEBUG|RELEASE
  SKUID_IDENTIFIER               = DEFAULT

[Components]
  Rx580ReBarDxe/Rx580LargeBarDxe.inf

!include MdePkg/MdeLibs.dsc.inc

[LibraryClasses]
  UefiDriverEntryPoint|MdePkg/Library/UefiDriverEntryPoint/UefiDriverEntryPoint.inf
  UefiBootServicesTableLib|MdePkg/Library/UefiBootServicesTableLib/UefiBootServicesTableLib.inf
  DebugLib|MdePkg/Library/UefiDebugLibConOut/UefiDebugLibConOut.inf
