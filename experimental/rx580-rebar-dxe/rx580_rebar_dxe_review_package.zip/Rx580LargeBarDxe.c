/**
 * Rx580LargeBarDxe.c
 *
 * Early UEFI DXE helper for RX 580 (1002:67df): request an 8 GiB BAR0 before
 * the PCI bus driver collects and allocates PCI resources. This is deliberately
 * a DXE driver, not a standalone EFI application: it hooks the host bridge's
 * PreprocessController callback during PCI enumeration.
 *
 * It only changes BAR0 when the device explicitly advertises 8 GiB in its
 * Resizable BAR supported-size mask. It never invents a capability or writes
 * a guessed register on devices that do not advertise that size.
 */
#include <Uefi.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/DebugLib.h>
#include <Library/UefiDriverEntryPoint.h>
#include <Protocol/PciRootBridgeIo.h>
#include <Protocol/PciHostBridgeResourceAllocation.h>

#define RX580_VENDOR_ID            0x1002
#define RX580_DEVICE_ID            0x67DF
#define PCI_EXT_CAP_START          0x100
#define PCI_EXT_CAP_END            0x1000
#define PCI_EXT_CAP_REBAR          0x0015
#define PCI_REBAR_CAP_OFFSET       0x04
#define PCI_REBAR_CTRL_OFFSET      0x08
#define PCI_REBAR_BAR_INDEX_MASK   0x00000007
#define PCI_REBAR_NBAR_MASK        0x000000E0
#define PCI_REBAR_NBAR_SHIFT       5
#define PCI_REBAR_SIZE_MASK        0x00003F00
#define PCI_REBAR_SIZE_SHIFT       8
#define PCI_REBAR_8G_SIZE_INDEX    13  /* ReBAR encodes 1 MiB as 0; 8 GiB is 2^13 MiB. */
#define MAX_HOST_BRIDGES           8
#define MAX_REBAR_ENTRIES          6
#define EXT_CAP_WALK_LIMIT         480

typedef struct {
  EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PROTOCOL *Protocol;
  EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PROTOCOL_PREPROCESS_CONTROLLER OriginalPreprocess;
} RX580_HOST_BRIDGE_HOOK;

STATIC RX580_HOST_BRIDGE_HOOK mHooks[MAX_HOST_BRIDGES];
STATIC UINTN mHookCount;

STATIC
RX580_HOST_BRIDGE_HOOK *
FindHook (
  IN EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PROTOCOL *This
  )
{
  UINTN Index;
  for (Index = 0; Index < mHookCount; ++Index) {
    if (mHooks[Index].Protocol == This) {
      return &mHooks[Index];
    }
  }
  return NULL;
}

STATIC
EFI_STATUS
ReadConfigDword (
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *RootBridgeIo,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS *PciAddress,
  IN UINTN Offset,
  OUT UINT32 *Value
  )
{
  UINT64 Address;

  if (Offset >= PCI_EXT_CAP_END || (Offset & 3) != 0) {
    return EFI_INVALID_PARAMETER;
  }

  Address = EFI_PCI_ADDRESS(PciAddress->Bus, PciAddress->Device,
                            PciAddress->Function, Offset);
  *Value = 0xFFFFFFFF;
  return RootBridgeIo->Pci.Read(RootBridgeIo, EfiPciWidthUint32,
                                Address, 1, Value);
}

STATIC
EFI_STATUS
WriteConfigDword (
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *RootBridgeIo,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS *PciAddress,
  IN UINTN Offset,
  IN UINT32 Value
  )
{
  UINT64 Address;

  if (Offset >= PCI_EXT_CAP_END || (Offset & 3) != 0) {
    return EFI_INVALID_PARAMETER;
  }

  Address = EFI_PCI_ADDRESS(PciAddress->Bus, PciAddress->Device,
                            PciAddress->Function, Offset);
  return RootBridgeIo->Pci.Write(RootBridgeIo, EfiPciWidthUint32,
                                 Address, 1, &Value);
}

STATIC
UINTN
FindResizableBarCapability (
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *RootBridgeIo,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS *PciAddress
  )
{
  UINTN Offset;
  UINTN Walk;
  UINT32 Header;
  EFI_STATUS Status;

  Offset = PCI_EXT_CAP_START;
  for (Walk = 0; Walk < EXT_CAP_WALK_LIMIT; ++Walk) {
    Status = ReadConfigDword(RootBridgeIo, PciAddress, Offset, &Header);
    if (EFI_ERROR(Status) || Header == 0 || Header == 0xFFFFFFFF) {
      return 0;
    }

    if ((Header & 0xFFFF) == PCI_EXT_CAP_REBAR) {
      return Offset;
    }

    Offset = (Header >> 20) & 0xFFC;
    if (Offset < PCI_EXT_CAP_START || Offset >= PCI_EXT_CAP_END) {
      return 0;
    }
  }

  return 0;
}

STATIC
EFI_STATUS
FindBar0ResizableControl (
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *RootBridgeIo,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS *PciAddress,
  IN UINTN RebarOffset,
  OUT UINTN *ControlOffset,
  OUT UINT32 *ControlValue
  )
{
  UINT32 FirstControl;
  UINT32 Control;
  UINT32 Capability;
  UINT32 SupportedSizes;
  UINTN EntryCount;
  UINTN Entry;
  UINTN CtrlOffset;
  EFI_STATUS Status;

  Status = ReadConfigDword(RootBridgeIo, PciAddress,
                           RebarOffset + PCI_REBAR_CTRL_OFFSET, &FirstControl);
  if (EFI_ERROR(Status) || FirstControl == 0xFFFFFFFF) {
    return EFI_DEVICE_ERROR;
  }

  EntryCount = (FirstControl & PCI_REBAR_NBAR_MASK) >> PCI_REBAR_NBAR_SHIFT;
  if (EntryCount == 0 || EntryCount > MAX_REBAR_ENTRIES) {
    return EFI_COMPROMISED_DATA;
  }

  for (Entry = 0; Entry < EntryCount; ++Entry) {
    CtrlOffset = RebarOffset + PCI_REBAR_CTRL_OFFSET + (8 * Entry);
    if (CtrlOffset + 4 > PCI_EXT_CAP_END) {
      return EFI_COMPROMISED_DATA;
    }

    Status = ReadConfigDword(RootBridgeIo, PciAddress, CtrlOffset, &Control);
    if (EFI_ERROR(Status) || Control == 0xFFFFFFFF) {
      return EFI_DEVICE_ERROR;
    }

    if ((Control & PCI_REBAR_BAR_INDEX_MASK) != 0) {
      continue; /* AMDGPU's framebuffer aperture is BAR0. */
    }

    Status = ReadConfigDword(RootBridgeIo, PciAddress,
                             CtrlOffset - PCI_REBAR_CAP_OFFSET, &Capability);
    if (EFI_ERROR(Status) || Capability == 0xFFFFFFFF) {
      return EFI_DEVICE_ERROR;
    }

    SupportedSizes = (Capability & 0xFFFFFFF0) >> 4;
    if ((SupportedSizes & (1U << PCI_REBAR_8G_SIZE_INDEX)) == 0) {
      return EFI_UNSUPPORTED;
    }

    *ControlOffset = CtrlOffset;
    *ControlValue = Control;
    return EFI_SUCCESS;
  }

  return EFI_NOT_FOUND;
}

STATIC
VOID
MaybeResizeRx580Bar0 (
  IN EFI_HANDLE RootBridgeHandle,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS PciAddress
  )
{
  EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL *RootBridgeIo;
  EFI_STATUS Status;
  UINT32 Id;
  UINTN RebarOffset;
  UINTN ControlOffset;
  UINT32 Control;
  UINT32 NewControl;
  UINT32 VerifyControl;

  RootBridgeIo = NULL;
  Status = gBS->HandleProtocol(RootBridgeHandle,
                               &gEfiPciRootBridgeIoProtocolGuid,
                               (VOID **)&RootBridgeIo);
  if (EFI_ERROR(Status) || RootBridgeIo == NULL) {
    return;
  }

  Status = ReadConfigDword(RootBridgeIo, &PciAddress, 0, &Id);
  if (EFI_ERROR(Status) || Id == 0xFFFFFFFF ||
      (Id & 0xFFFF) != RX580_VENDOR_ID || (Id >> 16) != RX580_DEVICE_ID) {
    return;
  }

  RebarOffset = FindResizableBarCapability(RootBridgeIo, &PciAddress);
  if (RebarOffset == 0) {
    DEBUG((DEBUG_WARN,
      "Rx580LargeBarDxe: %02x:%02x.%x: no readable ReBAR capability\n",
      PciAddress.Bus, PciAddress.Device, PciAddress.Function));
    return;
  }

  Status = FindBar0ResizableControl(RootBridgeIo, &PciAddress,
                                    RebarOffset, &ControlOffset, &Control);
  if (EFI_ERROR(Status)) {
    DEBUG((DEBUG_WARN,
      "Rx580LargeBarDxe: %02x:%02x.%x: BAR0 does not advertise 8 GiB (status %r)\n",
      PciAddress.Bus, PciAddress.Device, PciAddress.Function, Status));
    return;
  }

  if (((Control & PCI_REBAR_SIZE_MASK) >> PCI_REBAR_SIZE_SHIFT) ==
      PCI_REBAR_8G_SIZE_INDEX) {
    return; /* Already at 8 GiB. */
  }

  NewControl = (Control & ~PCI_REBAR_SIZE_MASK) |
               (PCI_REBAR_8G_SIZE_INDEX << PCI_REBAR_SIZE_SHIFT);
  Status = WriteConfigDword(RootBridgeIo, &PciAddress, ControlOffset, NewControl);
  if (EFI_ERROR(Status)) {
    DEBUG((DEBUG_ERROR,
      "Rx580LargeBarDxe: %02x:%02x.%x: failed to request 8 GiB BAR0 (%r)\n",
      PciAddress.Bus, PciAddress.Device, PciAddress.Function, Status));
    return;
  }

  Status = ReadConfigDword(RootBridgeIo, &PciAddress, ControlOffset, &VerifyControl);
  if (EFI_ERROR(Status) ||
      ((VerifyControl & PCI_REBAR_SIZE_MASK) >> PCI_REBAR_SIZE_SHIFT) !=
        PCI_REBAR_8G_SIZE_INDEX) {
    DEBUG((DEBUG_ERROR,
      "Rx580LargeBarDxe: %02x:%02x.%x: BAR0 size write did not verify (status %r, ctrl %08x)\n",
      PciAddress.Bus, PciAddress.Device, PciAddress.Function, Status, VerifyControl));
    return;
  }

  DEBUG((DEBUG_INFO,
    "Rx580LargeBarDxe: %02x:%02x.%x: requested 8 GiB BAR0 before PCI resource collection\n",
    PciAddress.Bus, PciAddress.Device, PciAddress.Function));
}

STATIC
EFI_STATUS
EFIAPI
PreprocessControllerOverride (
  IN EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PROTOCOL *This,
  IN EFI_HANDLE RootBridgeHandle,
  IN EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL_PCI_ADDRESS PciAddress,
  IN EFI_PCI_CONTROLLER_RESOURCE_ALLOCATION_PHASE Phase
  )
{
  RX580_HOST_BRIDGE_HOOK *Hook;
  EFI_STATUS Status;

  Hook = FindHook(This);
  if (Hook == NULL || Hook->OriginalPreprocess == NULL) {
    return EFI_UNSUPPORTED;
  }

  /* Preserve the platform's native callback and its status. */
  Status = Hook->OriginalPreprocess(This, RootBridgeHandle, PciAddress, Phase);

  /* PciBus invokes this before collecting resources. Once enumeration has
     allocated resources, changing the size alone is too late to be reliable. */
  if (Phase <= EfiPciBeforeResourceCollection) {
    MaybeResizeRx580Bar0(RootBridgeHandle, PciAddress);
  }

  return Status;
}

EFI_STATUS
EFIAPI
Rx580LargeBarDxeEntry (
  IN EFI_HANDLE ImageHandle,
  IN EFI_SYSTEM_TABLE *SystemTable
  )
{
  EFI_STATUS Status;
  EFI_HANDLE *Handles;
  UINTN HandleCount;
  UINTN Index;
  EFI_PCI_HOST_BRIDGE_RESOURCE_ALLOCATION_PROTOCOL *Protocol;

  (VOID)SystemTable;
  mHookCount = 0;
  Handles = NULL;
  HandleCount = 0;

  Status = gBS->LocateHandleBuffer(ByProtocol,
      &gEfiPciHostBridgeResourceAllocationProtocolGuid,
      NULL, &HandleCount, &Handles);
  if (EFI_ERROR(Status) || Handles == NULL) {
    DEBUG((DEBUG_WARN,
      "Rx580LargeBarDxe: PCI host bridge resource allocation protocol not found (%r)\n",
      Status));
    return EFI_SUCCESS; /* Never prevent the platform from booting. */
  }

  for (Index = 0; Index < HandleCount && mHookCount < MAX_HOST_BRIDGES; ++Index) {
    Protocol = NULL;
    Status = gBS->OpenProtocol(Handles[Index],
        &gEfiPciHostBridgeResourceAllocationProtocolGuid,
        (VOID **)&Protocol, ImageHandle, NULL, EFI_OPEN_PROTOCOL_GET_PROTOCOL);
    if (EFI_ERROR(Status) || Protocol == NULL ||
        Protocol->PreprocessController == NULL ||
        Protocol->PreprocessController == PreprocessControllerOverride) {
      continue;
    }

    mHooks[mHookCount].Protocol = Protocol;
    mHooks[mHookCount].OriginalPreprocess = Protocol->PreprocessController;
    Protocol->PreprocessController = PreprocessControllerOverride;
    ++mHookCount;
  }

  gBS->FreePool(Handles);
  DEBUG((DEBUG_INFO, "Rx580LargeBarDxe: hooked %u PCI host bridge(s)\n", mHookCount));

  /* A missing/unsupported host bridge must not break startup. */
  return EFI_SUCCESS;
}
