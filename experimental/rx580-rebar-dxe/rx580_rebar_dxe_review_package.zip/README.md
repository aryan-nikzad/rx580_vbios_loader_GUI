# RX 580 early 8 GiB BAR helper (review candidate)

This is a **companion DXE driver**, not an application to launch from GRUB. It targets PCI device `1002:67DF` and requests ReBAR size index `13` (8 GiB) for BAR0 only when the device's own ReBAR capability explicitly lists 8 GiB as supported. It uses `EFI_PCI_ROOT_BRIDGE_IO_PROTOCOL` for extended configuration reads and writes.

## Why this runs before the existing loader

`vbios_loader.efi` is launched from GRUB, after the motherboard's PCI bus driver has already enumerated devices and allocated BAR resources. A late write to the ReBAR control is not enough to guarantee that the 8 GiB aperture has been reserved and aligned. This helper hooks `PciHostBridgeResourceAllocationProtocol.PreprocessController` and changes the BAR size during `EfiPciBeforeResourceCollection`, while the firmware PCI bus driver is still preparing its resource allocations. The existing loader then runs later and performs the dead-SPI ROM/AtomBIOS initialization as it does today.

The hook is model-agnostic at the PCI bridge level but intentionally matches only `1002:67DF`. It does **not** flash either GPU or modify motherboard NVRAM. It does not invent a ReBAR capability: if BAR0 does not advertise 8 GiB support, it logs a debug warning and leaves the device unchanged. Healthy GPUs already running with 8 GiB are left unchanged.

## Build in an EDK2 workspace

1. Obtain and build a normal [TianoCore EDK2](https://github.com/tianocore/edk2) workspace with BaseTools and a supported X64 toolchain.
2. Copy this `ReBarDxe` folder to the root of that EDK2 workspace as `Rx580ReBarDxe/`.
3. From the EDK2 root, run:

   ```bash
   source edksetup.sh
   build -p Rx580ReBarDxe/Rx580ReBar.dsc -a X64 -t GCC5 -b DEBUG
   ```

   Adjust `GCC5` to the toolchain tag configured in your EDK2 environment. `DEBUG` uses EDK2’s `UefiDebugLibConOut` mapping in the supplied DSC so `DEBUG()` diagnostics go to the UEFI console when it is available. The expected PE/COFF image is under `Build/Rx580ReBarDxe/DEBUG_GCC5/X64/Rx580LargeBarDxe.efi`.

4. Package the driver as an FFS file using EDK2 BaseTools (`GenSec` and `GenFfs`) or a firmware-volume build that includes the INF. Do not launch the generated `.efi` as a UEFI application and expect it to resize bars: the component must be included in the motherboard firmware's DXE volume, with dispatch ordering/dependencies arranged so it hooks the host-bridge protocol before `PciBusDxe` starts PCI enumeration. Merely satisfying the driver dependency does not by itself guarantee it dispatches ahead of every platform PCI bus driver.

## Firmware installation and risk

Inserting a DXE driver into the motherboard firmware requires editing and reflashing the **host motherboard BIOS**, not the RX 580 ROM. This can brick the motherboard if the image or insertion location is wrong. Keep an unmodified BIOS backup and a known-good recovery method; review the produced FFS and the firmware volume layout before making any change. This candidate does not include a flash script and does not modify any firmware image automatically.

`Above 4G Decoding` and an adequate 64-bit PCI MMIO window must still be available. You already confirmed the platform can allocate 8 GiB BARs for the healthy cards; this helper is intended to request the same BAR0 size for the two cards whose SPI BIOS is dead. The code itself has **not been tested on your motherboard or compiled in an EDK2 workspace here**; treat it as a review candidate until built and tested.

## Verification

After adding the DXE driver to a test firmware and booting with the existing RX 580 loader, check Linux resource lengths and the ReBAR capability:

```bash
for d in 01:00.0 0c:00.0 0d:00.0 0e:00.0; do echo "=== $d ==="; sudo lspci -s "$d" -nnvv | grep -Ei 'Resizable BAR|Region 0|Region 2'; done
```

Use the live BDFs from `lspci -nn` if they differ. BAR0's allocated length should be 8 GiB on all four supported cards. If the capability is unreadable or does not advertise 8 GiB, do not force a guessed register write; inspect the debug output and a fresh status-aware PCI configuration dump first.
